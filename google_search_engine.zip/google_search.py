from tkinter import *
import tkinter as tk
import webbrowser
from PIL import ImageTk, Image

# Function to open links in a web browser
def callback(url):
    webbrowser.open_new_tab(url)

# Function to simulate search functionality
def search_query():
    query = text.get("1.0", "end-1c")
    webbrowser.open(f"https://www.google.com/search?q={query}")

# Create main window
root = tk.Tk()
root.title("Google Search Engine")
root.geometry("1000x700")

# Top black strip
Label(root, bg="black", width=500, height=2).grid(sticky="w")

# Google logo (Placeholder)
g_logo = Label(root, text="Google Logo Here", font=("Arial", 20, "bold"), fg="blue")
g_logo.place(x=350, y=190)

# Search entry box
text = Text(root, width=90, height=2, relief=RIDGE, font=('roboto', 10, 'bold'), borderwidth=2)
text.place(x=170, y=300)

# Search button
search1 = Button(root, text="Google Search", relief=RIDGE, font=('arial', 10), bg="#F3F3F3",
                 fg="#222222", cursor="hand2", command=search_query)
search1.place(x=350, y=360)

# I'm Feeling Lucky Button
lucky = Button(root, text="I'm Feeling Lucky", relief=RIDGE, font=('arial', 10), bg="#F3F3F3",
               fg="#222222", cursor="hand2", command=lambda: callback("https://www.google.com/doodles"))
lucky.place(x=500, y=360)

root.mainloop()
